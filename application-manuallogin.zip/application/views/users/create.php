<form method="post">
    Email: <input type="text" name="email" /><br />
    Password: <input type="password" name="password" /><br />
    Confirm Password: <input type="password" name="confirm" /><br />
    <input type="submit" value="Login" />
</form>
<a href="/users/create">Create account</a>
