News blog home page
