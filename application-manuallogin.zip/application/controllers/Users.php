<?php

class Users extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('users_model');
        $this->load->helper('html_helper');
        $this->load->helper('url_helper');
        $this->load->library('session');
    }

    public function dashboard() {
        echo "Weclome back " . $this->session->flashdata('user_id');
        exit;
    }
    
    public function login() {
        if ($this->input->post("email")) {
            $result = $this->users_model->checklogin();
            if ($result) {
                $this->session->set_flashdata('user_id', $result['id']);
                redirect('users/dashboard');
            } else {
                $data['msg'] = "Incorrect email or password";
            }
        }
        $data['title'] = "User login";
        $this->load->view('templates/header',$data);
        $this->load->view('users/login');
        $this->load->view('templates/footer');
    }

    public function create() {
        if ($this->input->post("email")) {
            $result = $this->users_model->createlogin();
            if (is_numeric($result)) { // the result (if numeric) is the newly created user_id
                $this->session->set_flashdata('user_id', $result);
                redirect('users/dashboard');
            } else { // return must have been an error message, let's set the message variable and reload the view
                $data['msg'] = $result;
            }
        }
        $data['title'] = "Create account";
        $this->load->view('templates/header',$data);
        $this->load->view('users/create');
        $this->load->view('templates/footer');
    }
    
}
