<?php

function debug($obj) {
    echo "<pre>";
    print_r($obj);
    echo "</pre>";
}

