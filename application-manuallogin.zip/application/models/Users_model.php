<?php

class Users_model extends CI_Model {

    public function __construct() {
        $this->load->database();
    }

    // checks "posted" login info
    public function checklogin() {
        $email = $this->input->post("email");
        $password = $this->input->post("password");
        $query = $this->db->get_where('users', array('email' => $email, 'password'=>sha1($password)));
        return $query->row_array();
    }

    // creates a new user account based on posted data
    public function createlogin() {
        $email = $this->input->post("email");
        $password = $this->input->post("password");
        $confirm = $this->input->post("confirm");
        if ($password != $confirm) {
            return "Passwords do not match.";
        }
        $data = array(
            'email' => $this->input->post('email'),
            'password' => sha1($this->input->post('password')),
            'role_id' => 1, // all accounts hard-coded to default role
            'created' => date("Y-m-d H:i:s")
        );
        $result = $this->db->insert('users', $data);
        if ($result) {
            return $this->db->insert_id();
        } else {
            return $this->db->_error_message();
        }
    }
    
    public function getreservations($user_id) {
        
    }

}
